# Git 101

Feifei Hang

[http://goo.gl/CJCQHO](http://goo.gl/CJCQHO)

![QR Code](img/qrcode.png)

---

## Install Git

Go to Git [download page](http://git-scm.com/downloads).

Once installed, test the install.

```cmd
git --version
```

---

## Config User Information

```cmd
git config --global user.name "Your name"

git config --global user.email "your@mail.address"
```

---

## List All Config

```cmd
git config --list
```

---

## Some Useful Settings

```cmd
# Colorize console output for readability
git config --global color.ui auto

# Unstage a file
git config --global alias.unstage 'reset HEAD --'
```

---

## Suggested by GitLab

```cmd
# Default editor
git config --global core.editor vim

# Linear commit tree when merge
git config --global branch.autosetuprebase always

# Only push current branch to remote
# Doesn't work for me... update Git...
git config --global push.default simple
```

---

## GitLab

[http://gitlab.cs.man.ac.uk](http://gitlab.cs.man.ac.uk)

![GitLab Connections](img/gitlab.png)

SSH Keygen: follow [GitLab Section 4.3](http://studentnet.cs.manchester.ac.uk/ugt/2013/COMP10120/labscripts/101lab4.pdf)

---

## GitLab

**Make sure all teammates are registered on GitLab.**

![GitLab Members](img/members.png)

---

## Create a Local Git Repo

--

## Init Repository From Scratch

```cmd
# New project
git init new_project
cd new_project
# start coding...
```

--

## Init Repository From Existing Dir

```cmd
# Legacy project tree
cd existing_project
git init

# Add all the code
git add .
git commit -am "Initial commit"
```

---

## Push a Repo to Remote

--

## Check Remotes

```cmd
# make sure you are in Git repo, then...
git remote show
```

--

## Add A Remote

```cmd
git remote add <remote> <URL>
```

*origin*: The first/default remote

--

## Change A Remote

```cmd
git remote set-url <remote> <URL>
```

--

## Push New Repo to Remote

```cmd
git push -u <remote> master
```

---

## Git Clone

To get a Git repo from remote

```cmd
git clone <URL>
```

or, if you want to give it another name...

```cmd
git clone <URL> <new_name>
```

---

## Add & Commit Code Changes

--

## What's the Status?

To check the status of a Git repo...

```cmd
git status
```

--

## A "Dirty" Repo Status

```cmd
# On branch master
# Untracked files:
#   (use "git add <file>..." to include in
#        what will be committed)
#
#       README.md
nothing added to commit but untracked files
present (use "git add" to track)
```

--

## Track a new file

Once a new file is added into repo...

```cmd
git add <filename>
```

--

## Untrack a file

To untrack a file...

```cmd
# Untrack & remove the file from local repo
git rm <filename>

# Only untrack the file, do not remove from local
git rm --cached <filename>
```

--

## Commit Changes

Once a new function/class/etc is implemented and tested...

```cmd
# Commit all tracked files
git commit -am "Say something about this commit"
```

or, let's do it one by one...

```cmd
# Only commit a specific file
git add <filename>
git commit -m "blah blah blah"
```

--

## Git File lifecycle

![File Lifecycle](img/lifecycle.png)

---

## Rollback last commit

--

If regret last commit...

<div class="fragments">
<div class="fragment">
**Do not use `git reset`!!!**
</div>
<div class="fragment">
You may *lose* your work.
</div>
</div>

--

## Git Revert

See last commit ID...

```cmd
git log --graph --oneline --color

* a488b5c Implemented awesome
* db6ab3d Implemented toast
* 332077b Revert "updated plus function"
```

Then revert it...

```cmd
git revert <commit>
# In this case, git revert a488b5c

# or...
git revert HEAD
```

--

## A bit further?

```cmd
git checkout <commit> <filename>
```

--

## After Revert

```cmd
* 1f972dc Revert "Implemented awesome"
* a488b5c Implemented awesome
* db6ab3d Implemented toast
* 332077b Revert "updated plus function"
```

---

## Branch

--

## Git Branch

To distribute work and add new/experimental features, it is a good idea to create separate branches.

![Git Branch](img/branch.png)

The initial branch is called "*master*".

--

## Create a Branch

**Discuss branch names with teammates!!!**

```cmd
# Only create a new branch
git branch <branch>

# Create a branch then checkout
git checkout -b <branch>
```

*checkout*: something like *cd* command

--

## Push New Branch to Remote

```cmd
git push -u origin <branch>
```

--

## Switch Branch

```cmd
git checkout <branch>
```

--

## Show Branches

```cmd
# show local branches
git branch

#show remote branches
git branch -r
```

--

## Delete Branch

```cmd
git branch -d <branch>
```

Close a branch from remote

```cmd
git tag closed-<branch> <branch>
git push --tags
git branch -d <branch>
git push <remote> :<branch>
```

--

## Set Upstream

Helps you to keep local branches synchronized with the remote ones.

```cmd
git fetch <remote>
git status
# Your branch is behind 'origin/master'
# by 1 commit.
```

To set upstream...

```cmd
git branch --set-upstream
    <branch> <remote>/<branch>
```

---

## Git Ignore



To ignore files (e.g. bins, some testings)...

Create a file called "**.gitignore**" in your repo (without quotes).

--

## An .gitignore Example

```cmd
# Compiled source #
*.pyc
*.class
*.dll
*.o
*.so

# Directories #
bin
code/built
```

---

## Upload Changes to Remote

```cmd
git push [-u] origin [branch]
```

---

## Get Code From Remote

--


## Git Fetch

To get everything up-to-date in local repo...

```cmd
git fetch <remote> [branch]
```

If want to keep an eye on other branches...

```cmd
# create a local branch and link it to remote
git fetch <remote>
git checkout -b <branch> <remote>/<branch>
```

**But not done yet...**

--

## Git Log

To see the commits in remote...

```cmd
# Show log of a remote branch
git log <remote>/<branch>
```

Can also check local repo...

```cmd
# Show log of a specific branch
git log [branch]

# Show log in all branches
git log --all
```

--

## A Log Example

```cmd
* 3ab7bb0 Added gitignore
*   6335ac8 Merge branch 'nightly'
|\
| * 9e68be6 Implemented plus
* |   167236c Solved conflicts
|\ \
| |/
| * afe425c Be more aggresive
* | da1edad Be polite
|/
* 24c39e9 Improved showInfo function
* c8f6cf1 Implemented showInfo
* 31450ba Print Hello World
* bdf98fc Added main.py
```

git log --oneline --graph --color --all

--

## Git Diff

To see the differences in code...

```cmd
# show diff by commit
git diff <commit> <filename>

# show diff by branch
git diff <remote>/<branch> <branch>
```

--

## A Diff Example

```cmd
diff --git a/main.py b/main.py
index bd66912..9da1372 100644
--- a/main.py
+++ b/main.py
@@ -4,9 +4,21 @@ def showInfo(name):
     name = 'Hello, ' + name + '!!!!!'
     return name

+def toast(msg):
+    return 'Awesome, ' + msg + '!!'
+
+def awesome():
+    print('awesome')
+

 print('Hello world!!!')
```

git diff 9e68be6 main.py

---

## Merge the Code

--

## Git Merge

![Git Merge](img/merge.png)

To put two branches together...

```cmd
# Merge branch hotfix with master
git checkout master
git merge hotfix
```

--

## Code Conflict

Sometimes when you try to merge...

```python
# master branch...
def sayHi(name):
    return 'Hi, ' + name

# nightly branch...
def sayHi(name):
    print('Welcome, ' + name)
```

```cmd
CONFLICT (content): Merge conflict in main.py
Automatic merge failed; fix conflicts and then
commit the result.
```

--

## Solve Conflict

```python
def sayHi(name):
<<<<<<< HEAD
    return 'Hi, ' + name
=======
    print('Welcome, ' + name)
>>>>>>> nightly
```

Manually solve the conflict and...

```cmd
git commit -am "Conflict Solved"
```

--

```cmd
*   4df3f7d Conflict solved
|\
| * 57e8dc7 Updated toString
* | 9ddf457 Improved toString
* |   aefa98e Merge branch 'developer'
|\ \
| |/
| * b809844 Implemented toString
* | 63a62db Added toString
| * afe425c Be more aggresive
* | da1edad Be polite
|/
* 31450ba Print Hello World
* bdf98fc Added main.py
```

---

## If the source code is so screwed...

--

## Who to blame?

```cmd
git blame <filename>
```

```cmd
50ba5 (F. Hang    18:57:29 1) #!/usr/bin/python
6cf1d (F. Hang    18:59:52 2) def showInfo(name):
425c2 (S. Ballmer 19:06:38 3)   computer, show it
425c2 (S. Ballmer 19:06:38 4)   on screen now!
39e96 (F. Hang    19:03:49 5)   return name
```

---

<section data-background-size="90%" data-background="img/cheatsheet.png"></section>

---

## GUI Clients

[http://git-scm.com/downloads/guis](http://git-scm.com/downloads/guis)

---

## Useful Links

* [Atlassian Git Tutorial](https://www.atlassian.com/git/tutorial)

* [Git - The Simple Guide](http://rogerdudler.github.io/git-guide/)

* [Try Git](http://try.github.io/)
